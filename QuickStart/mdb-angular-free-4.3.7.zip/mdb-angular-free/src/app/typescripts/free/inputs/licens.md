https://github.com/SebastianM/angular-google-maps/blob/master/LICENSE
https://www.npmjs.com/package/ng2-completer
https://github.com/jkuri/ngx-uploader
